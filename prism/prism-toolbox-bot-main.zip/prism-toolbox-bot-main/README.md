# prism-toolbox-bot

Minecraft（Bedrock 基岩版）机器人工具箱。包含：

- `bot-apk/`：Go 编写的机器人服务端与 Android 壳（前端嵌入式）。
- `flowers-for-machines/`：AGPL-3.0 协议依赖的本地副本（含 tanlobby 本地联机模块）。

## 协议

本仓库整体遵循 **GNU AGPL-3.0**。详见 [LICENSE](LICENSE)。

> 注意：出于安全考虑，签名校验等内容不包含在内。
